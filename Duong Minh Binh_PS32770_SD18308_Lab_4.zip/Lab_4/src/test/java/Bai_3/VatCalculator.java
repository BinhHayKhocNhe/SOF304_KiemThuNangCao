package Bai_3;

public class VatCalculator {

	public double getVatOnAmount(double	amount) {
		return amount*0.1;
	}

}

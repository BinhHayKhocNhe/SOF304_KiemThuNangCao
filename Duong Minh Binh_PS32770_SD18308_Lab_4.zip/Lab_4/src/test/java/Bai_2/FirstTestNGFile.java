package Bai_2;

import org.testng.annotations.Test;

public class FirstTestNGFile {
  @Test
  public void f() {
	  System.out.println("Output Test Case 1");
  }
}

package Bai_3;

import java.util.ArrayList;

public class TestAnnotations {
	ArrayList<String> list;
}

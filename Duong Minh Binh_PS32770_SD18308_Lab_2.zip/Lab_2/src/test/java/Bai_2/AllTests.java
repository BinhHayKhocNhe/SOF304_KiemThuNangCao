package Bai_2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ JUnitMessageTest1.class, JUnitMessageTest2.class })
public class AllTests {
	
}
